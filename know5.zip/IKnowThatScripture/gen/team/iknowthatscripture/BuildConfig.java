/** Automatically generated file. DO NOT MODIFY */
package team.iknowthatscripture;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}